PixelRevive beginner IPCV sample dataset

10 original synthetic test images (640 x 420 pixels).
These images are generated for educational use.

Use DATASET_GUIDE.csv for suggested algorithms.
Upload PNG images individually, as a group, or upload this ZIP if your app supports ZIP datasets.

Note: Gaussian and average blurs smooth images rather than perfectly restore them. Sharpening does not truly reverse heavy blur.
Images 06 and 07 are noisy versions of image 01, while 04, 05 and 08 are degraded versions of image 01.
